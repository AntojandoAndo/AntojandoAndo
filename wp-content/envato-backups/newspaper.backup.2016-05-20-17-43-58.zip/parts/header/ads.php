<div class="td-header-rec-wrap">
    <?php

    // show the header ad spot
    echo td_global_blocks::get_instance('td_block_ad_box')->render(array('spot_id' => 'header')); ?>

</div>